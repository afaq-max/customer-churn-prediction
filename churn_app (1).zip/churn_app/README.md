# Customer Churn Prediction – Flask Web App (Assignment 2)

Student: Afaq Muzammil · SAP ID 70175004 · Artificial Intelligence

Web application built on the Logistic Regression pipeline from Assignment 1
(Telco Customer Churn dataset).

## Project structure

```
churn_app/
├── app.py                  Flask backend (routes, validation, prediction)
├── train_model.py          Re-creates the Assignment 1 pipeline and saves the model
├── model.joblib            Saved sklearn Pipeline (imputer + scaler + one-hot + LogisticRegression)
├── feature_info.json       Feature order, dropdown options, metrics
├── requirements.txt
├── wsgi_pythonanywhere.py  Template for the PythonAnywhere WSGI file
├── data/WA_Fn-UseC_-Telco-Customer-Churn.csv
├── templates/index.html    Form + result page
├── static/style.css        Styling
└── tests/test_app.py       Local tests (18 checks)
```

## Run locally

```bash
pip install -r requirements.txt
python train_model.py        # optional: regenerates model.joblib
python app.py                # open http://127.0.0.1:5000
python tests/test_app.py     # run the test-suite
```

## Deploy on PythonAnywhere

1. Sign up / log in at https://www.pythonanywhere.com (free "Beginner" account is enough).
2. **Files** tab → upload `churn_app.zip` into your home directory.
3. **Consoles** tab → *Bash*:
   ```bash
   cd ~
   unzip churn_app.zip            # creates /home/YOURUSERNAME/churn_app
   cd churn_app
   mkvirtualenv churnenv --python=python3.10   # use a Python version offered by your account
   pip install -r requirements.txt
   python train_model.py          # IMPORTANT: re-creates model.joblib with THIS server's scikit-learn
   ```
4. **Web** tab → *Add a new web app* → *Manual configuration* → choose the same Python version.
5. On the Web tab set:
   * **Source code**: `/home/YOURUSERNAME/churn_app`
   * **Virtualenv**: `/home/YOURUSERNAME/.virtualenvs/churnenv`
   * **Static files**: URL `/static/` → Directory `/home/YOURUSERNAME/churn_app/static`
6. Click the **WSGI configuration file** link, delete its contents and paste `wsgi_pythonanywhere.py`
   (change `YOURUSERNAME`).
7. Press the green **Reload** button. Your site is live at
   `https://YOURUSERNAME.pythonanywhere.com`.
8. If you see an error page, open the **Error log** link on the Web tab.

### Common problems

| Symptom | Fix |
|---|---|
| `ModuleNotFoundError` | Virtualenv path not set on the Web tab, or `pip install` was done outside the virtualenv |
| `InconsistentVersionWarning` / unpickle error | Run `python train_model.py` on PythonAnywhere to rebuild `model.joblib` |
| Page has no styling | Add the `/static/` mapping on the Web tab |
| `FileNotFoundError: model.joblib` | Wrong `project_home` path in the WSGI file |
