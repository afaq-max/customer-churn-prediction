# ----------------------------------------------------------------------------
# PythonAnywhere WSGI configuration  (paste into the WSGI file shown on the
# "Web" tab, e.g. /var/www/YOURUSERNAME_pythonanywhere_com_wsgi.py)
#
# 1. Replace YOURUSERNAME with your PythonAnywhere username.
# 2. Replace "churn_app" if your project folder has a different name.
# ----------------------------------------------------------------------------
import sys

project_home = "/home/YOURUSERNAME/churn_app"
if project_home not in sys.path:
    sys.path.insert(0, project_home)

# 'app' is the Flask object defined in app.py ->  app = Flask(__name__)
from app import app as application   # noqa: E402
