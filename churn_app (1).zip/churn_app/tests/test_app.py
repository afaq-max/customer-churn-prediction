"""
Local tests for the churn web app.  Run from the project folder:   python tests/test_app.py
Checks: (1) happy-path churn / no-churn, (2) web result == direct model result,
(3) validation / error handling never crashes.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
from app import app, model, FEATURE_ORDER

client = app.test_client()
BASE = Path(__file__).resolve().parent.parent

CHURN = dict(gender="Female", SeniorCitizen="0", Partner="No", Dependents="No", tenure="2",
             PhoneService="Yes", MultipleLines="No", InternetService="Fiber optic",
             OnlineSecurity="No", OnlineBackup="No", DeviceProtection="No", TechSupport="No",
             StreamingTV="No", StreamingMovies="No", Contract="Month-to-month",
             PaperlessBilling="Yes", PaymentMethod="Electronic check",
             MonthlyCharges="70.70", TotalCharges="151.65")
STAY = dict(gender="Male", SeniorCitizen="0", Partner="Yes", Dependents="Yes", tenure="60",
            PhoneService="Yes", MultipleLines="Yes", InternetService="DSL",
            OnlineSecurity="Yes", OnlineBackup="Yes", DeviceProtection="Yes", TechSupport="Yes",
            StreamingTV="No", StreamingMovies="No", Contract="Two year",
            PaperlessBilling="No", PaymentMethod="Bank transfer (automatic)",
            MonthlyCharges="65.00", TotalCharges="3900.00")

passed = failed = 0
def check(name, cond):
    global passed, failed
    print(("PASS  " if cond else "FAIL  ") + name)
    passed += cond; failed += (not cond)

def post(data):
    r = client.post("/predict", data=data)
    return r.status_code, r.get_data(as_text=True)

# ---- 1. expected churn / no-churn cases
code, html = post(CHURN)
check("expected-churn customer -> 'Churn' shown (HTTP 200)", code == 200 and "result-churn" in html)
code, html = post(STAY)
check("expected-stay customer  -> 'No Churn' shown (HTTP 200)", code == 200 and "result-stay" in html)

# ---- 2. web prediction == direct model prediction on real dataset rows
df = pd.read_csv(BASE / "data" / "WA_Fn-UseC_-Telco-Customer-Churn.csv")
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df = df.dropna(subset=["TotalCharges"]).sample(60, random_state=1)
mismatch = 0
for _, r in df.iterrows():
    form = {c: str(r[c]) for c in FEATURE_ORDER if c != "TenureGroup"}
    form["tenure"] = str(int(r["tenure"]))
    form["SeniorCitizen"] = str(int(r["SeniorCitizen"]))
    code, html = post(form)
    web_churn = "result-churn" in html
    row = {c: r[c] for c in FEATURE_ORDER if c != "TenureGroup"}
    row["tenure"] = int(r["tenure"]); row["SeniorCitizen"] = int(r["SeniorCitizen"])
    row["TenureGroup"] = str(pd.cut([row["tenure"]], [-1, 12, 24, 48, 72],
                             labels=["0-12 months", "13-24 months", "25-48 months", "49-72 months"])[0])
    direct = int(model.predict(pd.DataFrame([row], columns=FEATURE_ORDER))[0]) == 1
    mismatch += (web_churn != direct)
check(f"web vs direct model agree on 60 real customers (mismatches: {mismatch})", mismatch == 0)

# ---- 3. validation / error handling
code, html = post({})
check("empty form -> friendly errors, no crash (HTTP 400)", code == 400 and "Please fix" in html)
bad = dict(STAY, tenure="abc")
code, html = post(bad); check("text in tenure -> message", code == 400 and "must be a number" in html)
bad = dict(STAY, tenure="-5");  code, html = post(bad); check("negative tenure -> message", code == 400 and "negative" in html)
bad = dict(STAY, tenure="12.5"); code, html = post(bad); check("fractional tenure -> message", code == 400 and "whole number" in html)
bad = dict(STAY, tenure="500"); code, html = post(bad); check("tenure 500 -> too large", code == 400 and "too large" in html)
bad = dict(STAY, MonthlyCharges="nan"); code, html = post(bad); check("'nan' monthly -> message", code == 400)
bad = dict(STAY, Contract="Lifetime"); code, html = post(bad); check("invalid dropdown value -> message", code == 400 and "not a valid choice" in html)
bad = dict(STAY); bad.pop("Contract"); code, html = post(bad); check("missing dropdown -> message", code == 400 and "Please select" in html)
bad = dict(STAY, SeniorCitizen="7"); code, html = post(bad); check("bad senior flag -> message", code == 400)
bad = dict(STAY, PhoneService="Yes", MultipleLines="No phone service"); code, html = post(bad)
check("inconsistent phone answers -> message", code == 400)
ok = dict(STAY); ok.pop("TotalCharges"); code, html = post(ok)
check("blank TotalCharges -> estimated + note, still predicts", code == 200 and "estimated" in html)
ok = dict(STAY, InternetService="No"); code, html = post(ok)
check("no internet -> add-ons auto-set, still predicts", code == 200 and "No internet service" in html)
check("GET / works", client.get("/").status_code == 200)
check("GET /predict -> friendly 405 page", client.get("/predict").status_code == 405)
check("unknown URL -> friendly 404 page", client.get("/nothing").status_code == 404)

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
