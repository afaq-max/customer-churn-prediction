"""
app.py  -  Customer Churn Prediction web application (Assignment 2)

Flow:  browser form  ->  /predict (POST)  ->  validate  ->  build one-row
DataFrame in the SAME column order as training  ->  saved sklearn Pipeline
(imputer + scaler + one-hot encoder + Logistic Regression)  ->  friendly result.
"""
import json
from pathlib import Path

import joblib
import pandas as pd
from flask import Flask, render_template, request

BASE_DIR = Path(__file__).resolve().parent          # absolute paths: needed on PythonAnywhere

app = Flask(__name__)

# ------------------------------------------------------------------ load artifacts once
model = joblib.load(BASE_DIR / "model.joblib")
with open(BASE_DIR / "feature_info.json") as f:
    INFO = json.load(f)

FEATURE_ORDER = INFO["feature_order"]               # exact training column order
CATEGORIES = INFO["categories"]                     # allowed dropdown values
RANGES = INFO["numeric_ranges"]                     # min / max seen in training data

YES_NO_FIELDS = ["Partner", "Dependents", "PhoneService", "PaperlessBilling"]
INTERNET_ADDONS = ["OnlineSecurity", "OnlineBackup", "DeviceProtection",
                   "TechSupport", "StreamingTV", "StreamingMovies"]

# Friendly names used in error messages
LABELS = {
    "gender": "Gender", "SeniorCitizen": "Senior citizen", "Partner": "Partner",
    "Dependents": "Dependents", "tenure": "Tenure", "PhoneService": "Phone service",
    "MultipleLines": "Multiple lines", "InternetService": "Internet service",
    "OnlineSecurity": "Online security", "OnlineBackup": "Online backup",
    "DeviceProtection": "Device protection", "TechSupport": "Tech support",
    "StreamingTV": "Streaming TV", "StreamingMovies": "Streaming movies",
    "Contract": "Contract", "PaperlessBilling": "Paperless billing",
    "PaymentMethod": "Payment method", "MonthlyCharges": "Monthly charges",
    "TotalCharges": "Total charges",
}


# ------------------------------------------------------------------ helpers
def tenure_group(months: int) -> str:
    """Same bins as Assignment 1:  pd.cut(tenure, [-1,12,24,48,72])."""
    cut = pd.cut([months], bins=INFO["tenure_bins"], labels=INFO["tenure_labels"])
    return str(cut[0])


def validate_and_build(form):
    """
    Returns (row_dict, errors, notes).
    - errors: list of user-friendly messages (empty list = input is valid)
    - notes : extra information shown with the result (e.g. auto-filled values)
    """
    errors, notes, row = [], [], {}

    # ---- categorical fields: must be present and one of the known options
    for col in INFO["categorical_features"]:
        if col == "TenureGroup":                    # derived later, not typed by user
            continue
        value = (form.get(col) or "").strip()
        if not value:
            errors.append(f"Please select a value for “{LABELS[col]}”.")
        elif value not in CATEGORIES[col]:
            errors.append(f"“{value}” is not a valid choice for {LABELS[col]}.")
        else:
            row[col] = value

    # ---- SeniorCitizen is stored as 0/1 in the dataset
    senior = (form.get("SeniorCitizen") or "").strip()
    if senior not in ("0", "1"):
        errors.append("Please select whether the customer is a senior citizen.")
    else:
        row["SeniorCitizen"] = int(senior)

    # ---- numeric fields
    def read_number(name, integer=False, required=True):
        raw = (form.get(name) or "").strip().replace(",", "")
        if raw == "":
            if required:
                errors.append(f"Please enter {LABELS[name].lower()}.")
            return None
        try:
            val = float(raw)
        except ValueError:
            errors.append(f"{LABELS[name]} must be a number (you entered “{raw}”).")
            return None
        if val != val or val in (float("inf"), float("-inf")):
            errors.append(f"{LABELS[name]} must be a valid number.")
            return None
        if integer and val != int(val):
            errors.append(f"{LABELS[name]} must be a whole number of months.")
            return None
        lo, hi = RANGES[name]
        if val < 0:
            errors.append(f"{LABELS[name]} cannot be negative.")
            return None
        # hard upper limits keep absurd values out; training range is 0-72 months
        limits = {"tenure": 72, "MonthlyCharges": 500, "TotalCharges": 20000}
        if val > limits[name]:
            errors.append(f"{LABELS[name]} looks too large (maximum accepted: {limits[name]:,}).")
            return None
        return int(val) if integer else val

    tenure = read_number("tenure", integer=True)
    monthly = read_number("MonthlyCharges")
    total = read_number("TotalCharges", required=False)

    if errors:
        return None, errors, notes

    # ---- keep answers consistent with how the dataset encodes dependencies
    if row["PhoneService"] == "No" and row["MultipleLines"] != "No phone service":
        row["MultipleLines"] = "No phone service"
        notes.append("Multiple lines was set to “No phone service” because the customer has no phone service.")
    if row["PhoneService"] == "Yes" and row["MultipleLines"] == "No phone service":
        errors.append("“Multiple lines” cannot be “No phone service” when the customer has phone service.")
    if row["InternetService"] == "No":
        changed = False
        for col in INTERNET_ADDONS:
            if row[col] != "No internet service":
                row[col] = "No internet service"
                changed = True
        if changed:
            notes.append("Internet add-on services were set to “No internet service” because the customer has no internet.")
    else:
        for col in INTERNET_ADDONS:
            if row[col] == "No internet service":
                errors.append(f"“{LABELS[col]}” cannot be “No internet service” when the customer has internet service.")
    if errors:
        return None, errors, notes

    # ---- TotalCharges: optional -> estimate if blank
    if total is None:
        total = round(tenure * monthly, 2)
        notes.append(f"Total charges was left blank, so it was estimated as tenure × monthly charges = {total:,.2f}.")
    if tenure == 0 and total > 0:
        errors.append("A customer with 0 months of tenure should not have total charges above 0.")
        return None, errors, notes

    row["tenure"] = tenure
    row["MonthlyCharges"] = monthly
    row["TotalCharges"] = total
    row["TenureGroup"] = tenure_group(tenure)       # engineered feature from Assignment 1
    return row, errors, notes


def predict_one(row: dict):
    """Apply the saved pipeline to one customer. Returns (label, churn_probability)."""
    frame = pd.DataFrame([row], columns=FEATURE_ORDER)   # enforce training column order
    pred = int(model.predict(frame)[0])
    prob = float(model.predict_proba(frame)[0][1])
    return ("Churn" if pred == 1 else "No Churn"), prob


def risk_level(prob: float) -> str:
    if prob >= 0.60:
        return "High"
    if prob >= 0.35:
        return "Medium"
    return "Low"


# ------------------------------------------------------------------ routes
@app.route("/", methods=["GET"])
def home():
    return render_template("index.html", categories=CATEGORIES, form={}, result=None,
                           errors=[], notes=[], metrics=INFO["metrics"][INFO["model_name"]],
                           model_name=INFO["model_name"])


@app.route("/predict", methods=["POST"])
def predict():
    form = request.form
    row, errors, notes = validate_and_build(form)
    result = None
    if not errors:
        try:
            label, prob = predict_one(row)
            result = {
                "label": label,
                "probability": round(prob * 100, 1),
                "risk": risk_level(prob),
                "message": (
                    "This customer is likely to leave the company. Consider a retention offer or a follow-up call."
                    if label == "Churn"
                    else "This customer is likely to stay with the company."
                ),
            }
        except Exception:                            # never show a stack trace to the user
            app.logger.exception("Prediction failed")
            errors.append("Something went wrong while making the prediction. Please check your inputs and try again.")
    return render_template("index.html", categories=CATEGORIES, form=form, result=result,
                           errors=errors, notes=notes, metrics=INFO["metrics"][INFO["model_name"]],
                           model_name=INFO["model_name"]), (400 if errors else 200)


@app.errorhandler(404)
def not_found(_):
    return render_template("index.html", categories=CATEGORIES, form={}, result=None,
                           errors=["That page does not exist. Use the form below to make a prediction."],
                           notes=[], metrics=INFO["metrics"][INFO["model_name"]],
                           model_name=INFO["model_name"]), 404


@app.errorhandler(405)
def method_not_allowed(_):
    return render_template("index.html", categories=CATEGORIES, form={}, result=None,
                           errors=["Please submit the form on this page to get a prediction."],
                           notes=[], metrics=INFO["metrics"][INFO["model_name"]],
                           model_name=INFO["model_name"]), 405


if __name__ == "__main__":
    app.run(debug=True)
