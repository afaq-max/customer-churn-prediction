"""
train_model.py  -  Assignment 2 (carry forward + save the Assignment 1 model)

This script repeats the Assignment 1 pipeline EXACTLY (same cleaning, same
TenureGroup feature, same 80/20 stratified split with random_state=42, same
ColumnTransformer, same two models), picks the best model, and saves:

    model.joblib         - the complete fitted sklearn Pipeline
                           (imputer + scaler + one-hot encoder + classifier)
    feature_info.json    - feature order, dropdown options, numeric ranges,
                           and test-set metrics (used by the Flask app)

Run once:   python train_model.py
"""
import json
import warnings
from pathlib import Path

import joblib
import pandas as pd
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

warnings.filterwarnings("ignore", category=Warning)   # hide harmless pandas/sklearn version notices

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data" / "WA_Fn-UseC_-Telco-Customer-Churn.csv"

# ---------------------------------------------------------------- 1. load
df = pd.read_csv(DATA_FILE)
print("Dataset loaded:", df.shape)

# ---------------------------------------------------------------- 2. clean
data = df.copy()
data["TotalCharges"] = pd.to_numeric(data["TotalCharges"], errors="coerce")
data = data.dropna(subset=["TotalCharges"]).copy()      # 11 blank rows removed
data = data.drop(columns=["customerID"])

# Feature engineering (same bins as Assignment 1)
data["TenureGroup"] = pd.cut(
    data["tenure"],
    bins=[-1, 12, 24, 48, 72],
    labels=["0-12 months", "13-24 months", "25-48 months", "49-72 months"],
)
# Stored as plain strings so the web app can build the same column easily
data["TenureGroup"] = data["TenureGroup"].astype(str)

# ---------------------------------------------------------------- 3. split
X = data.drop(columns=["Churn"])
y = data["Churn"].map({"No": 0, "Yes": 1})

categorical_features = X.select_dtypes(include=["object", "category"]).columns.tolist()
numeric_features = X.select_dtypes(exclude=["object", "category"]).columns.tolist()

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)

# ---------------------------------------------------------------- 4. pipeline
numeric_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler()),
])
categorical_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore")),
])
preprocessor = ColumnTransformer([
    ("num", numeric_pipeline, numeric_features),
    ("cat", categorical_pipeline, categorical_features),
])

candidates = {
    "Logistic Regression": Pipeline([
        ("preprocessor", preprocessor),
        ("model", LogisticRegression(max_iter=2000)),
    ]),
    "Random Forest": Pipeline([
        ("preprocessor", preprocessor),
        ("model", RandomForestClassifier(
            n_estimators=300, random_state=42,
            class_weight="balanced", n_jobs=-1)),
    ]),
}

# ---------------------------------------------------------------- 5. train + evaluate
results = {}
for name, pipe in candidates.items():
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    results[name] = {
        "accuracy": round(accuracy_score(y_test, pred), 4),
        "precision": round(precision_score(y_test, pred, zero_division=0), 4),
        "recall": round(recall_score(y_test, pred, zero_division=0), 4),
        "f1": round(f1_score(y_test, pred, zero_division=0), 4),
        "confusion_matrix": confusion_matrix(y_test, pred).tolist(),
    }
    print(f"{name:20s}", {k: v for k, v in results[name].items() if k != "confusion_matrix"})

# Assignment 1 selected Logistic Regression as the final model, so it is carried
# forward here. (Random Forest scores can shift slightly between library versions,
# so the model is NOT re-selected automatically - it is fixed to the Assignment 1 choice.)
best_name = "Logistic Regression"
final_model = candidates[best_name]
print("\nBest model carried forward:", best_name)

# ---------------------------------------------------------------- 6. save
joblib.dump(final_model, BASE_DIR / "model.joblib")

feature_info = {
    "model_name": best_name,
    "sklearn_version": sklearn.__version__,
    "feature_order": X.columns.tolist(),           # exact column order used in training
    "numeric_features": numeric_features,
    "categorical_features": categorical_features,
    "categories": {c: sorted(X[c].unique().tolist()) for c in categorical_features},
    "numeric_ranges": {
        c: [float(X[c].min()), float(X[c].max())]
        for c in ["tenure", "MonthlyCharges", "TotalCharges"]
    },
    "tenure_bins": [-1, 12, 24, 48, 72],
    "tenure_labels": ["0-12 months", "13-24 months", "25-48 months", "49-72 months"],
    "metrics": results,
}
with open(BASE_DIR / "feature_info.json", "w") as f:
    json.dump(feature_info, f, indent=2)

print("Saved: model.joblib and feature_info.json")
print("Feature order:", feature_info["feature_order"])
